//
//  ContactInfo.swift
//  
//
//  Created by Ward on 25/04/2018.
//

import Foundation
struct ContactInfo {
    let Name: Name
}
