//
//  user.swift
//  CroCo
//
//  Created by Louis Loeckx on 24/04/2018.
//  Copyright © 2018 VDAB. All rights reserved.
//

import Foundation

struct User {
    let userName: String
    let name: String
    let email: String
    let adress: String
}
