//
//  Location.swift
//  CroCo
//
//  Created by Ward Janssen on 28/04/2018.
//  Copyright © 2018 VDAB. All rights reserved.
//

import Foundation
