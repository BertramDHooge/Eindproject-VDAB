//
//  Crops.swift
//  CroCo
//
//  Created by Louis Loeckx on 25/04/2018.
//  Copyright © 2018 VDAB. All rights reserved.
//

import Foundation

struct Stock {
    var portion: Portion
    var amountOfStockPortionsAvailable: Int
    var amountOfStockSelected: Int
    var totalCostOfSelectedStock: Double
}
