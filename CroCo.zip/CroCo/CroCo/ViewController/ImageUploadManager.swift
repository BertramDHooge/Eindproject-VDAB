//
//  ImageUploadManager.swift
//  CroCo
//
//  Created by Ward on 08/05/2018.
//  Copyright © 2018 VDAB. All rights reserved.
//

import UIKit
import Firebase

class ImageUploadManager: NSObject {
//    func uploadImage(_ image: UIImage, completionBlock: _url: String?, _ errorMessage: String?) -> Void {
//
//    }
}
